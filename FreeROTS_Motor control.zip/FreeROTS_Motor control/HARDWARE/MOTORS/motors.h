#ifndef __MOTORS_H
#define __MOTORS_H
#include "sys.h"

//��������˿ڶ���
#define PX PAout(4)
#define PY PAout(6)	
#define PZ PCout(4)	
#define DX PAout(5)	
#define DY PAout(7)
#define DZ PCout(5)	
#define PW PBout(0)	
#define DW PBout(1)	
#define OPEN PBout(2)	

void Motors_Init(void);//��ʼ��		 				    
#endif

