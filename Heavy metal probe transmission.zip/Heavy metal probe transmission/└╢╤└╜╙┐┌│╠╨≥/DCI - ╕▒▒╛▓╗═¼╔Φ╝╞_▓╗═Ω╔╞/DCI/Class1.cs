﻿using System;
using InTheHand.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;





namespace DCI
{
    public class DCIC
    {
        BluetoothListener bluetoothListener;
        BluetoothClient bluetoothClient;
        private string data = "";
        public bool dataok = false;
        public bool bluetoothisConnected = false;
        byte [] sendcmd;
        public int BLUETOOTHSTART()
        {
            Thread listenThread = new Thread(ReceiveData);
            listenThread.Start();
            return 0;
        }
        private void SendData(string data)
        {

            UInt32 crc;//无符号整数校验值
            string head = "##";//包头
            string data_length = "0000";//数据段长度
            string crc_codes = "0000"; //校验值初始化字符串           
            byte[] end = new byte[2];//包尾回车换行
            end[0] = 0x0d;//回车
            end[1] = 0x0a;//换行
            byte[] buffer0 = new byte[2000];//定义中间字节数组

            data_length = Convert.ToString(data.Length);//数据段长度赋值
            data_length = data_length.ToString().PadLeft(4, '0');//数据段长度格式化为四位数字的字符串
            crc = CRC_Check(data, (UInt32)data.Length);//计算CRC校验值
            data = head + data_length + data;//将包头、数据段长度、数据段连接在一起
            crc_codes = Convert.ToString(crc, 16);//将无符号整数校验值转换为字符串
            crc_codes = crc_codes.ToString().PadLeft(4, '0');//格式化字符串校验值为四位字符型十六进制表示 例如：1E00
            data = data + crc_codes.ToUpper();//将校验值全部大写并附加在数据包上
            buffer0 = Encoding.Default.GetBytes(data);//将字符数据包转换为字节数组
                                                      //int test = Convert.ToInt32(data.Length);//测试变量
            byte[] buffer = new byte[buffer0.Length + 2];//定义确定长度的字节数组确保数据发送出去是没有后缀0的
            buffer0.CopyTo(buffer, 0);//将中间字节数组的数据拷贝到最终的字节数组
            end.CopyTo(buffer, buffer0.Length);//将包尾连接到最终的字节数组
            sendcmd = buffer;
            if (bluetoothClient.Connected)//如果蓝牙连接则发送数据
            {
                try
                {
                    System.Net.Sockets.NetworkStream peerStream = bluetoothClient.GetStream();
                    peerStream.Write(buffer, 0, buffer.Length);
                }
                catch (Exception)
                {
                   
                }
            }
            //Thread datacheck = new Thread(DataSendCheck);
            //datacheck.Start();

        }
        private void DataSendCheck()
        {
            var cmd = sendcmd;
            int outtime=0;
            while (!dataok) ;
            for (int i = 0; i < 3; i++)//重试3次
            {
                outtime = 0;
                for (int j = 0; j < 10; j++)
                {
                    if ((!data.Contains("CP=&&QnRtn=1&&")) || (!data.Contains("CP=&&ExeRtn=1&&")))
                    {
                        outtime++;
                        Thread.Sleep(1000);
                    }
                    else break;
                    if (outtime == 10)
                    {
                        if (bluetoothClient.Connected)//如果蓝牙连接则发送数据
                        {
                            try
                            {
                                System.Net.Sockets.NetworkStream peerStream = bluetoothClient.GetStream();
                                peerStream.Write(cmd, 0, cmd.Length);
                            }
                            catch (Exception)
                            {

                            }
                        }
                    }
                }
                

            }
        }
        private UInt32 CRC_Check(string puchMsg, UInt32 usDataLen)
        {
            UInt32 i, j, crc_reg, check;
            crc_reg = 0xFFFF;
            for (i = 0; i < usDataLen; i++)
            {
                crc_reg = (crc_reg >> 8) ^ puchMsg[(Int32)i];
                for (j = 0; j < 8; j++)
                {
                    check = crc_reg & 0x0001;
                    crc_reg >>= 1;
                    if (check == 0x0001)
                    {
                        crc_reg ^= 0xA001;
                    }
                }
            }
            return crc_reg;
        }    
        private void ReceiveData()
        {
            //蓝牙串口服务的uuid  00001101-0000-1000-8000-00805F9B34FB  设备的uuid bc9abf53348a4fbf8dabe0c946c14988     

            bluetoothListener = new BluetoothListener(Guid.Parse("bc9abf53348a4fbf8dabe0c946c14988"));
            bluetoothListener.Start();//开始监听
            while (!bluetoothisConnected)
            {
                try
                {

                    bluetoothClient = bluetoothListener.AcceptBluetoothClient();
                    bluetoothisConnected = true;
                    Device_CheckIn();

                }
                catch (Exception)
                {
                    bluetoothisConnected = false;
                }
                while (bluetoothClient.Connected)
                {
                    string receive = string.Empty;
                    if (bluetoothClient == null)
                    {
                        break;
                    }
                    try
                    {
                        System.Net.Sockets.NetworkStream peerStream = bluetoothClient.GetStream();
                        byte[] buffer = new byte[1036];
                        peerStream.Read(buffer, 0, 1036);

                        receive = Encoding.UTF8.GetString(buffer).ToString();
                        receive = receive.TrimEnd('\0');

                        if ((receive[0] == '#') & (receive[1] == '#') & (receive[receive.Length - 2] == 0x0d) & (receive[receive.Length - 1] == 0x0a))
                        {
                            int crc = Convert.ToInt32(receive.Substring(receive.Length - 6, 4), 16);
                            int len = Convert.ToInt32(receive.Substring(2, 4));
                            receive = receive.Substring(6, len);//截取出数据段

                            if (CRC_Check(receive, (UInt32)receive.Length) == crc)
                            {
                                
                                try
                                {
                                    buffer = Encoding.UTF8.GetBytes(receive);
                                    data = receive;
                                    dataok = true;   


                                }
                                catch (Exception)
                                {

                                }
                            }
                            else
                            {
                                //MessageBox.Show("接收数据crc校验错误");
                            }
                        }



                    }
                    catch (System.Exception)
                    {
                        bluetoothClient.Close();
                        bluetoothClient.Dispose();
                    }
                    Thread.Sleep(100);
                }
                bluetoothisConnected = false;
                Thread.Sleep(1000);
            }
        }
        public string CmdData()
        {
            if (dataok)
            {
                return data;
            }
            else
            {
                return "";
            }
        }


        /// <summary>
        /// 设备登录函数
        /// </summary>
        private void Device_CheckIn()
        {
            if (bluetoothisConnected)
            {
                string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=3011;PW=1234;MN=1011212;Flag=1;CP=&&&&";//QN=20160801085857223;ST=31;CN=3011;PW=1234;MN=1011157;Flag=1;CP=&&&&
                SendData(cmd);
            }
        }

        /// <summary>
        /// 设置测试时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Set_testtime(String test_time)//测试时间,默认为60
        {
            if (bluetoothisConnected)
            {
                string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=1011;PW=1234;MN=1011212;Flag=1;CP=&&B1Duration=";
                string cmd1 = "&&";
                cmd = cmd + test_time + cmd1;
                SendData(cmd);
            }
        }

        /// <summary>
        /// 设置超时重发
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Set_tt_tr(string tt,string rt)//超时时间,默认为10//重发次数，默认为3
        {
            if (bluetoothisConnected)
            {
                string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=1000;PW=1234;MN=1011212;Flag=1;CP=&&OverTime=";
                string overtime = "";
                string cmd1 = ";ReCount=";
                string ReCount = "";
                string cmd2 = "&&";
                overtime = tt;
                ReCount = rt;
                cmd = cmd + overtime + cmd1 + ReCount + cmd2;
                SendData(cmd);
            }
        }
        public void StopClick()
        {
            string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=2012;PW=1234;MN=1011212;Flag=1;CP=&&&&";
            SendData(cmd);
        }
        public void StartClick()
        {
            string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=2011;PW=1234;MN=1011212;Flag=1;CP=&&&&";
            SendData(cmd);
        }
        public void SelfCheckClick()
        {
            string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=3012;PW=1234;MN=1011212;Flag=1;CP=&&&&";
            SendData(cmd);
        }
        public void ShutDown()
        {
            string cmd = "QN=" + DateTime.Now.ToString("yyyyMMddhhmmssfff") + ";ST=31;CN=3014;PW=1234;MN=1011212;Flag=1;CP=&&&&";
            SendData(cmd);
        }
        public void ReceiveFlag(string qn,string mn)
        {
            SendData("QN=" + qn + ";ST=91;CN=9014;PW=1234;MN=" + mn + ";Flag=0;CP=&&&&");

        }
    }
}
