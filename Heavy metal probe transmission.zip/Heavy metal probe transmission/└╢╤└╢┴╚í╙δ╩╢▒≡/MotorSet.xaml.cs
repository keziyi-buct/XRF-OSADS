﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Configuration;

namespace 蓝牙读取与识别
{
    /// <summary>
    /// MotorSet.xaml 的交互逻辑
    /// </summary>
    public partial class MotorSet : Window
    {
        IMotor motor = new Serial_IO();
        public MotorSet()
        {
            InitializeComponent(); 
            string[] strCom = SerialPort.GetPortNames();
            if (strCom == null)
            {
                MessageBox.Show("机械设备通讯异常，请检查");
            }
            foreach (string com in strCom)
            {
                CB1.Items.Add(com);
            }
            CB2.Items.Add("9600");
            CB2.Items.Add("115200");
        }

        private void OpenClose_Click(object sender, RoutedEventArgs e)
        {
            if (RB1.IsChecked == true)
            {
                motor.SerialClose(CB1.SelectedItem.ToString(),CB2.SelectedItem.ToString());
                RB1.IsChecked = false;
            }
            else if(RB1.IsChecked==false)
            {
                ConfigurationManager.AppSettings["com"] = CB1.SelectedItem.ToString();
                ConfigurationManager.AppSettings["baudrate"] = CB2.SelectedItem.ToString();
                ConfigurationManager.AppSettings["ComState"] ="1";
                RB1.IsChecked = true;
            }
        }

        private void XSL_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            XSV.Text = XSL.Value.ToString("F2");
           
            ConfigurationManager.AppSettings["x"] = XSV.Text;
        }

        private void YSL_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            YSV.Text = YSL.Value.ToString("F2");
            ConfigurationManager.AppSettings["y"] = YSV.Text;
        }

        private void ZSL_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ZSV.Text = ZSL.Value.ToString("F2");
            ConfigurationManager.AppSettings["z"] = ZSV.Text;
        }

        private void WSL_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            WSV.Text = WSL.Value.ToString("F2");
            ConfigurationManager.AppSettings["w"] = WSV.Text;
        }


        private void Remember_Click(object sender, RoutedEventArgs e)
        {
            motor.SerialSend(Encoding.UTF8.GetBytes(XSV.Text));
            motor.SerialSend(Encoding.UTF8.GetBytes(YSV.Text));
            motor.SerialSend(Encoding.UTF8.GetBytes(ZSV.Text));
            motor.SerialSend(Encoding.UTF8.GetBytes(WSV.Text));
        }

        private void ResetLocationClick(object sender, RoutedEventArgs e)
        {
            XSV.Text = "0";
            XSL.Value = 0;
            YSV.Text = "0";
            YSL.Value = 0;
            ZSV.Text = "0";
            ZSL.Value = 0;
            WSV.Text = "0";
            WSL.Value = 0;
        }
    }
}
