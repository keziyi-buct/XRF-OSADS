﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 蓝牙读取与识别.Models
{
    public class HMDetecResult
    {
        public string BoxId { get; set; }
        public string QRCode { get; set; }

        public double Cd { get; set; }
        public double Hg { get; set; }
        public double As { get; set; }
        public double Pb { get; set; }
        public double Cr { get; set; }
        public double Zn { get; set; }
        public double Cu { get; set; }
    }
}
