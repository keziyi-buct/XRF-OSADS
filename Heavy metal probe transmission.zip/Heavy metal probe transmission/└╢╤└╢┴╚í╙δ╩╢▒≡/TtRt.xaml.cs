﻿using DCI;
using System.Windows;
using System.Windows.Input;

namespace 蓝牙读取与识别
{
    /// <summary>
    /// TtRt.xaml 的交互逻辑
    /// </summary>
    public partial class TtRt : Window
    {
        DCIC Dci = new DCIC();
        public TtRt()
        {
            InitializeComponent();
        }

        public bool enter_staute = false;

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            if (Dci.bluetoothisConnected)
            {
                Dci.Set_tt_tr(tt_txb.Text, rt_txb.Text);
                this.Close();
            }
            else
            { MessageBox.Show("探头未连接"); }
        }






        private void Rt_txb_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            rt_txb.Text = "";
        }

        private void Tt_txb_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            tt_txb.Text = "";
        }
    }
}
