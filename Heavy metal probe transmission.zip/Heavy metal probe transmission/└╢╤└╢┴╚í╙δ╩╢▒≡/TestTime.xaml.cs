﻿using DCI;
using System.Windows;
using System.Windows.Input;

namespace 蓝牙读取与识别
{
    /// <summary>
    /// TestTime.xaml 的交互逻辑
    /// </summary>
    public partial class TestTime : Window
    {
        DCIC Dci = new DCIC();
        public TestTime()
        {
            InitializeComponent();
            
        }
        public bool enter_staute = false;

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            if (Dci.bluetoothisConnected)
            {
                Dci.Set_testtime(txb.Text);
                this.Close();
            }
            else
            { MessageBox.Show("探头未连接"); }
        }

        private void Txb_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txb.Text = "";
        }
    }
}
