﻿using DCI;
using System.IO;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Management;

namespace 蓝牙读取与识别
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        IMotor motor = new Serial_IO();
        SocketOfSoilService soss = new SocketOfSoilService();
        string[] SoilEllipse =
 { "A1", "A2", "A3", "A4", "A5", "A6", "B1", "B2", "B3", "B4", "B5", "B6", "C1", "C2", "C3", "C4", "C5", "C6", "D1", "D2", "D3", "D4", "D5", "D6", "E1", "E2", "E3", "E4", "E5", "E6" ,"A0"};
        bool Ellipse_state = false;
        bool Measure_state = false;
        bool Pause_state = false;
        bool Stop_state = false;
        int StatueLength = 0;
        string com;
        static string filePath;
        string buard = "115200";
        string CurrrentEllipse = "A0";
        DCIC Dci = new DCIC();//蓝牙接口
        Dictionary<string, string> DataRead = new Dictionary<string, string>();//数据字典
        Dictionary<string, Ellipse> Ellipses = new Dictionary<string, Ellipse>();//控件字典
        Dictionary<string, string> CodeRead = new Dictionary<string, string>();//编码字典
        public delegate void SetTextCallback(string text);
        public delegate void SetStringCallback();
        public delegate void CrossThreadOperationControl();

        public MainWindow()
        {
            InitializeComponent();
            CreatFils();//建立日志文件
            //ComSelect();
            //motor.SerialInit(com, buard); //如果脱机测试（无机械部分）则注释掉这部分
            Dci.bluetoothisConnected = false;//测试设备模拟蓝牙连接就设置为true
            Dci.BLUETOOTHSTART();
            //Thread ClientThread = new Thread(SocketReceiveData);
            // ClientThread.Start();
            Thread BlueThread = new Thread(BluetoothReceiveData);
            BlueThread.Start();//蓝牙接收线程初始化
            Timer_my();//定时初始化
            DitAdd();//字典添加
            Timer_Ellipse();//界面刷新显示
            SetWindowToFront();//定时保持界面处于当前位置最前的位置
            MessageBox.Show("设备MN="+Dci.MN);

        }
        private void ComSelect()
        {
            string ss = MulGetHardwareInfo(HardwareEnum.Win32_PnPEntity, "Name");
            try
            {
                if (ss[ss.IndexOf("COM") + 4] == ')')
                { com = "COM" + ss[ss.IndexOf("COM") + 3]; }
                else com = "COM" + ss[ss.IndexOf("COM") + 3] + ss[ss.IndexOf("COM") + 4];

            }
            catch (Exception)
            {
                MessageBox.Show("内部设备连接线脱落");
                using (FileStream stream = new FileStream(filePath, FileMode.Append))
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine("内部设备连接线脱落     " + DateTime.Now.ToString("yyyyMMddhhmmss"));
                    writer.Flush();
                    writer.Close();
                    stream.Close();
                }
                System.Environment.Exit(0);
            }

        }
        private void CreatFils()
        {
            try
            {
                string path = @".\log";
                File.ReadAllLines(path + "\\" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt");

            }
            catch (Exception)
            {
                string path = @".\log";
                var c = File.Create(path + "\\" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt");
                c.Close();
            }
            filePath = @".\log\\" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt";
        }
        /// <summary>
        /// 枚举win32 api
        /// </summary>
        public enum HardwareEnum
        {
            // 硬件
            Win32_Processor, // CPU 处理器
            Win32_PhysicalMemory, // 物理内存条
            Win32_Keyboard, // 键盘
            Win32_PointingDevice, // 点输入设备，包括鼠标。
            Win32_FloppyDrive, // 软盘驱动器
            Win32_DiskDrive, // 硬盘驱动器
            Win32_CDROMDrive, // 光盘驱动器
            Win32_BaseBoard, // 主板
            Win32_BIOS, // BIOS 芯片
            Win32_ParallelPort, // 并口
            Win32_SerialPort, // 串口
            Win32_SerialPortConfiguration, // 串口配置
            Win32_SoundDevice, // 多媒体设置，一般指声卡。
            Win32_SystemSlot, // 主板插槽 (ISA & PCI & AGP)
            Win32_USBController, // USB 控制器
            Win32_NetworkAdapter, // 网络适配器
            Win32_NetworkAdapterConfiguration, // 网络适配器设置
            Win32_Printer, // 打印机
            Win32_PrinterConfiguration, // 打印机设置
            Win32_PrintJob, // 打印机任务
            Win32_TCPIPPrinterPort, // 打印机端口
            Win32_POTSModem, // MODEM
            Win32_POTSModemToSerialPort, // MODEM 端口
            Win32_DesktopMonitor, // 显示器
            Win32_DisplayConfiguration, // 显卡
            Win32_DisplayControllerConfiguration, // 显卡设置
            Win32_VideoController, // 显卡细节。
            Win32_VideoSettings, // 显卡支持的显示模式。

            // 操作系统
            Win32_TimeZone, // 时区
            Win32_SystemDriver, // 驱动程序
            Win32_DiskPartition, // 磁盘分区
            Win32_LogicalDisk, // 逻辑磁盘
            Win32_LogicalDiskToPartition, // 逻辑磁盘所在分区及始末位置。
            Win32_LogicalMemoryConfiguration, // 逻辑内存配置
            Win32_PageFile, // 系统页文件信息
            Win32_PageFileSetting, // 页文件设置
            Win32_BootConfiguration, // 系统启动配置
            Win32_ComputerSystem, // 计算机信息简要
            Win32_OperatingSystem, // 操作系统信息
            Win32_StartupCommand, // 系统自动启动程序
            Win32_Service, // 系统安装的服务
            Win32_Group, // 系统管理组
            Win32_GroupUser, // 系统组帐号
            Win32_UserAccount, // 用户帐号
            Win32_Process, // 系统进程
            Win32_Thread, // 系统线程
            Win32_Share, // 共享
            Win32_NetworkClient, // 已安装的网络客户端
            Win32_NetworkProtocol, // 已安装的网络协议
            Win32_PnPEntity,//all device
        }
        /// <summary>
        /// WMI取硬件信息
        /// </summary>
        /// <param Name="hardType"></param>
        /// <param Name="propKey"></param>
        /// <returns></returns>
        public static string MulGetHardwareInfo(HardwareEnum hardType, string propKey)
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("select * from " + hardType))
                {
                    var hardInfos = searcher.Get();
                    foreach (var hardInfo in hardInfos)
                    {
                        string NN = hardInfo.Properties[propKey].Value.ToString();
                        if (NN.Contains("CH340"))
                        {
                            using (FileStream stream = new FileStream(filePath, FileMode.Append))
                            using (StreamWriter writer = new StreamWriter(stream))
                            {
                                writer.WriteLine("当前设备名称："+ NN + DateTime.Now.ToString("yyyyMMddhhmmss"));
                                writer.Flush();
                                writer.Close();
                                stream.Close();
                            }
                            return NN;
                        }

                    }

                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        private void BluetoothReceiveData()
        {
            string receive = "";
            while (true)
            {
                if (Dci.dataok)
                {
                    receive = Dci.CmdData();
                    using (FileStream stream = new FileStream(filePath, FileMode.Append))
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        writer.WriteLine("接受蓝牙回传数据：" + receive + DateTime.Now.ToString("yyyyMMddhhmmss"));
                        writer.Flush();
                        writer.Close();
                        stream.Close();
                    }
                    CmdCheck(receive);
                    Dci.dataok = false;
                }
            }

        }
        private void DitAdd()
        {
            DataRead.Add("QN", "20180808080808080");
            DataRead.Add("ST", "00");
            DataRead.Add("CN", "0000");
            DataRead.Add("PW", "0000");
            DataRead.Add("MN", "0000000");
            DataRead.Add("Flag", "0");
            DataRead.Add("No", "000");
            DataRead.Add("Sample", "#422");
            DataRead.Add("Mode", "Alloy");
            DataRead.Add("DataTime", "2000-01-29-05:33:02");
            DataRead.Add("Duration", "6.0");
            DataRead.Add("Unit", "%");
            DataRead.Add("Lon", "000.0000000");
            DataRead.Add("Lat", "000.0000000");
            DataRead.Add("PCBTemp", "35");
            DataRead.Add("Detemp", "-642.7");
            DataRead.Add("PeakPos", "76");
            DataRead.Add("24-Content", "0");
            DataRead.Add("24-Error", "0");
            DataRead.Add("29-Content", "0");
            DataRead.Add("29-Error", "0");
            DataRead.Add("30-Content", "0");
            DataRead.Add("30-Error", "0");
            DataRead.Add("33-Content", "0");
            DataRead.Add("33-Error", "0");
            DataRead.Add("48-Content", "0");
            DataRead.Add("48-Error", "0");
            DataRead.Add("80-Content", "0");
            DataRead.Add("80-Error", "0");
            DataRead.Add("82-Content", "0");
            DataRead.Add("82-Error", "0");
            Ellipses.Add("A1", Soil_A1);
            Ellipses.Add("A2", Soil_A2);
            Ellipses.Add("A3", Soil_A3);
            Ellipses.Add("A4", Soil_A4);
            Ellipses.Add("A5", Soil_A5);
            Ellipses.Add("A6", Soil_A6);
            Ellipses.Add("B1", Soil_B1);
            Ellipses.Add("B2", Soil_B2);
            Ellipses.Add("B3", Soil_B3);
            Ellipses.Add("B4", Soil_B4);
            Ellipses.Add("B5", Soil_B5);
            Ellipses.Add("B6", Soil_B6);
            Ellipses.Add("C1", Soil_C1);
            Ellipses.Add("C2", Soil_C2);
            Ellipses.Add("C3", Soil_C3);
            Ellipses.Add("C4", Soil_C4);
            Ellipses.Add("C5", Soil_C5);
            Ellipses.Add("C6", Soil_C6);
            Ellipses.Add("D1", Soil_D1);
            Ellipses.Add("D2", Soil_D2);
            Ellipses.Add("D3", Soil_D3);
            Ellipses.Add("D4", Soil_D4);
            Ellipses.Add("D5", Soil_D5);
            Ellipses.Add("D6", Soil_D6);
            Ellipses.Add("E1", Soil_E1);
            Ellipses.Add("E2", Soil_E2);
            Ellipses.Add("E3", Soil_E3);
            Ellipses.Add("E4", Soil_E4);
            Ellipses.Add("E5", Soil_E5);
            Ellipses.Add("E6", Soil_E6);
            CodeRead.Add("CODEA1", "");
            CodeRead.Add("CODEA2", "");
            CodeRead.Add("CODEA3", "");
            CodeRead.Add("CODEA4", "");
            CodeRead.Add("CODEA5", "");
            CodeRead.Add("CODEA6", "");
            CodeRead.Add("CODEB1", "");
            CodeRead.Add("CODEB2", "");
            CodeRead.Add("CODEB3", "");
            CodeRead.Add("CODEB4", "");
            CodeRead.Add("CODEB5", "");
            CodeRead.Add("CODEB6", "");
            CodeRead.Add("CODEC1", "");
            CodeRead.Add("CODEC2", "");
            CodeRead.Add("CODEC3", "");
            CodeRead.Add("CODEC4", "");
            CodeRead.Add("CODEC5", "");
            CodeRead.Add("CODEC6", "");
            CodeRead.Add("CODED1", "");
            CodeRead.Add("CODED2", "");
            CodeRead.Add("CODED3", "");
            CodeRead.Add("CODED4", "");
            CodeRead.Add("CODED5", "");
            CodeRead.Add("CODED6", "");
            CodeRead.Add("CODEE1", "");
            CodeRead.Add("CODEE2", "");
            CodeRead.Add("CODEE3", "");
            CodeRead.Add("CODEE4", "");
            CodeRead.Add("CODEE5", "");
            CodeRead.Add("CODEE6", "");
            ShowValue();
        }
        private void KillProcess(string processName)
        {
            Process[] myproc = Process.GetProcesses();
            foreach (Process item in myproc)
            {
                if (item.ProcessName == processName)
                {
                    item.Kill();
                }
            }
        }
        //private void SocketReceiveData()
        //{
        //    string Code = "";
        //    string code1 = "";
        //    string code2 = "";
        //    soss.SocketOfService();
        //    while (true)
        //    {
        //        while (SocketOfSoilService.socketconnect == true)
        //        {
        //            string DataTcp = soss.ReadTcp();
        //            SetTextCallback d2 = new SetTextCallback(SetText);   // 托管调用
        //            this.Dispatcher.Invoke(d2, new object[] { DataTcp.Trim('\0') });
        //            if (DataTcp == "Stat;time;IOTHM0001;")
        //            {
        //                soss.ReCmd();

        //                if (Dci.bluetoothisConnected)//Dci.bluetoothisConnected
        //                {
        //                    Thread Measure = new Thread(Measure_all);
        //                    if (!Measure.IsAlive)
        //                    {
        //                        Measure.Start();
        //                    }
        //                    else//测量线程已存在
        //                    {
        //                        Measure_state = true;//开始下一个测量
        //                        Pause_state = false;//取消暂停
        //                    }
        //                    soss.ReExc();
        //                }
        //                else
        //                {
        //                    soss.ReExcE();
        //                }

        //            }
        //            else if (DataTcp == "Stop;0;IOTHM0001;")
        //            {
        //                soss.ReCmd();

        //                if (Dci.bluetoothisConnected)
        //                {
        //                    tbx.Text = "停止测量";
        //                    Dci.StopClick();

        //                    Stop_state = true;
        //                    Measure_state = true;
        //                    soss.ReExc();
        //                }
        //                else
        //                {
        //                    soss.ReExcE();
        //                }
        //            }
        //            else if (DataTcp == "Rece;0;IOTHM0001;")
        //            {

        //            }
        //            else if (DataTcp.Length > 4)
        //            {
        //                if (DataTcp.Substring(0, 4) == "Reco")
        //                {
        //                    soss.ReCmd();
        //                    Code = DataTcp.Substring(5, DataTcp.Length - 16);
        //                    code1 = Code.Substring(0, 2);
        //                    code2 = Code.Substring(3, Code.Length - 3);
        //                    CodeRead["CODE" + code1] = code2;
        //                    soss.ReExc();
        //                }
        //                else
        //                {
        //                    soss.ReExcE();
        //                }
        //            }
        //        }
        //    }


        //}

        /// <summary>
        /// 定时函数，1秒一个定时用于刷新检测状态
        /// </summary>
        private void Timer_Ellipse()
        {
            DispatcherTimer dispatcherTimerEllipse = new DispatcherTimer();
            dispatcherTimerEllipse.Tick += new EventHandler(DispatcherTimer_TickEllipse);
            dispatcherTimerEllipse.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimerEllipse.Start();
        }
        /// <summary>
        /// 回调函数，在定时函数中反复调用，内容是刷新椭圆的颜色
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        private void DispatcherTimer_TickEllipse(object sender, EventArgs e)
        {
            foreach (KeyValuePair<string, Ellipse> kvp in Ellipses)
            {
                if ((Convert.ToByte(kvp.Key, 16)) < (Convert.ToByte(CurrrentEllipse, 16)))
                {
                    kvp.Value.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF007ACC"));
                }
                else if ((Convert.ToByte(kvp.Key, 16)) == (Convert.ToByte(CurrrentEllipse, 16)))
                {

                    if (Ellipse_state)
                    {
                        kvp.Value.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF007ACC"));
                    }
                    else
                    {
                        kvp.Value.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFD0E3F7"));
                    }
                    Ellipse_state = !Ellipse_state;

                }
                else
                {
                    kvp.Value.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFD0E3F7"));
                }
            }
        }

        /// <summary>
        /// 测量线程
        /// </summary>
        private void Measure_all()
        {
            Labelstart.Dispatcher.BeginInvoke((ThreadStart)delegate { this.Labelstart.Content = "测量下一盘"; });
            BoxIn.Dispatcher.BeginInvoke((ThreadStart)delegate { this.BoxIn.IsEnabled = false; });
            BoxOut.Dispatcher.BeginInvoke((ThreadStart)delegate { this.BoxOut.IsEnabled = false; });
            //motor.StartLocation();
            Thread.Sleep(100);
            //while (!motor.SerialRece().Contains("StartLocation"))
            //{
            //    Thread.Sleep(100);
            //}
            for (int i = 0; i < 30; i++)
            {
                Measure_state = false;
                while (Pause_state) ;
                CurrrentEllipse = SoilEllipse[i];
                if (Dci.bluetoothisConnected)
                {
                    SetTextCallback d = new SetTextCallback(SetText);   // 托管调用
                    this.Dispatcher.Invoke(d, new object[] { "开始测量" });
                    using (FileStream stream = new FileStream(filePath, FileMode.Append))
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        writer.WriteLine("开始测量     " + DateTime.Now.ToString("yyyyMMddhhmmss"));
                        writer.Flush();
                        writer.Close();
                        stream.Close();
                    }
                    //motor.Start();
                    //Thread.Sleep(100);
                    //while (!motor.SerialRece().Contains("Start"))
                    //{
                    //    Thread.Sleep(100);
                    //    //MessageBox.Show("未等到单片机返回下一个测量指令");
                    //}
                    while (Pause_state) ;
                    Dci.StartClick();
                    Measure_state = true;

                }
                while (Measure_state) ;
                while (Pause_state) ;
                if (Stop_state)
                {
                    CurrrentEllipse = "A0";
                    Stop_state = false;
                    //MessageBox.Show("退出测量");
                    break;
                }
                //motor.NextItem();
                //Thread.Sleep(100);
                //while (!motor.SerialRece().Contains("NextItem"))
                //{
                //    Thread.Sleep(100);
                //   // MessageBox.Show("未等到单片机返回下一个测量指令");
                //}
                while (Pause_state) ;
                using (FileStream stream = new FileStream(filePath, FileMode.Append))
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine("Current Item:"+ CurrrentEllipse + "NextItem     " + DateTime.Now.ToString("yyyyMMddhhmmss"));
                    writer.Flush();
                    writer.Close();
                    stream.Close();
                }

            }
            CurrrentEllipse = "A0";
            BoxIn.Dispatcher.BeginInvoke((ThreadStart)delegate { this.BoxIn.IsEnabled = true; });
            BoxOut.Dispatcher.BeginInvoke((ThreadStart)delegate { this.BoxOut.IsEnabled = true; });

        }


        /// <summary>
        /// 定时函数，1秒一个定时用于刷新当前状态
        /// </summary>
        private void Timer_my()
        {
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(DispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }

        /// <summary>
        /// 回调函数，在定时函数中反复调用，内容是查询各个状态量是否为ture
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (Dci.bluetoothisConnected&& ((StatueLength==0)|| (StatueLength >= 100)))
            {
                connect_state.IsChecked = true;
                StartBar.Visibility = Visibility.Collapsed;
                StartProcessPercent.Visibility = Visibility.Collapsed;
                if (IMGST_NAME.Content.ToString() != "关闭探头")
                {
                    Thread thread = new Thread(new ThreadStart(() =>
                    {
                        IMGST.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGST.IsEnabled = true; });
                        IMGSTART.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGSTART.IsEnabled = true; });
                        IMGPAUSE.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGPAUSE.IsEnabled = true; });
                        IMGSC.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGSC.IsEnabled = true; });
                        IMGSTOP.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGSTOP.IsEnabled = true; });
                        //motor.Reset();
                        //while (!motor.SerialRece().Contains("Reset"))
                        //{
                        //    Thread.Sleep(100);
                        //}
                        //motor.w_reset();
                        //while (!motor.SerialRece().Contains("w_reset"))
                        //{
                        //    Thread.Sleep(100);
                        //}
                    }));
                    thread.Start();
                    IMGST_NAME.Content = "关闭探头";
                }
            }
            else
            {
                connect_state.IsChecked = false;
            }
            
            if (Measure_state)//Measure_state
            {
                lb_status.Foreground = System.Windows.Media.Brushes.Blue;
                lb_status.Text = "正在测量……"; 
            }
            else
            {
               
            }

        }

        public class ChimcalElement
        {
            public string Name { get; set; }
            public string Percent { get; set; }
            public string Unit { get; set; }

        }
        
        /// <summary>
        /// 控件显示实际数据值
        /// </summary>
        public  void ShowValue()
        {
            list_percent.ItemsSource = new ChimcalElement[]{
                new ChimcalElement{Name="Cr",Percent=DataRead["24-Content"],Unit="ppm"},
                new ChimcalElement {Name="Cu",Percent=DataRead["29-Content"], Unit="ppm"},
                new ChimcalElement{ Name="Zn", Percent=DataRead["30-Content"], Unit="ppm" },
                new ChimcalElement { Name="As", Percent=DataRead["33-Content"], Unit="ppm" },
                new ChimcalElement {Name="Cd",Percent=DataRead["48-Content"], Unit="ppm"},
                new ChimcalElement{ Name="Hg", Percent=DataRead["80-Content"], Unit="ppm" },
                new ChimcalElement { Name="Pb", Percent=DataRead["82-Content"], Unit="ppm" }
            };
        }

        /// <summary>
        /// 委托设置text的值
        /// </summary>
        /// <param Name="text"></param>
        public void SetText(string text)
        {
            text = text + "\r";
            tbx.AppendText(text);

        }

        /// <summary>
        /// 蓝牙接收数据检测函数                  
        /// </summary>
        /// <param Name="Cmd"></param>
        private void CmdCheck(string Cmd)
        {
            string[] Cmds = Cmd.Split(';');
            for (int i = 0; i < Cmds.Length; i++)
            {
                if (Cmds[i].IndexOf("CN") >= 0)
                {
                    DataRead["CN"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("QN") >= 0)
                {
                    DataRead["QN"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("MN") >= 0)
                {
                    DataRead["MN"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("Duration") >= 0)
                {
                    DataRead["Duration"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("Unit") >= 0)
                {
                    DataRead["Unit"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("24-Content") >= 0)
                {
                    DataRead["24-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("24-Error") >= 0)
                {
                    DataRead["24-Error"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("29-Content") >= 0)
                {
                    DataRead["29-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("29-Error") >= 0)
                {
                    DataRead["29-Error"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("30-Content") >= 0)
                {
                    DataRead["30-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("30-Error") >= 0)
                {
                    DataRead["30-Error"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("33-Content") >= 0)
                {
                    DataRead["33-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("33-Error") >= 0)
                {
                    DataRead["33-Error"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("48-Content") >= 0)
                {
                    DataRead["48-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("48-Error") >= 0)
                {
                    DataRead["48-Error"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("80-Content") >= 0)
                {
                    DataRead["80-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("80-Error") >= 0)
                {
                    DataRead["80-Error"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("82-Content") >= 0)
                {
                    DataRead["82-Content"] = Cmds[i].Split('=')[1];
                }
                else if (Cmds[i].IndexOf("82-Error") >= 0)
                {
                    DataRead["82-Error"] = Cmds[i].Split('=')[1];
                }


            }

            try
            {
                if (Cmd.Contains("CP=&&QnRtn=1&&"))
                //##0075QN=20160801085857223;ST=91;CN=9011;PW=1234;MN=1011157;Flag=0;CP=&&QnRtn=1&&5000
                {
                    SetTextCallback d = new SetTextCallback(SetText);   // 托管调用
                    this.Dispatcher.Invoke(d, new object[] { "收到请求应答" });
                    if (StartBar.Visibility == Visibility.Visible)
                    {
                        StatueLength = 70;
                    }
                }
                else if (Cmd.Contains("CP=&&ExeRtn=1&&"))
                //##0076QN=20160801085857223;ST=91;CN=9012;PW=1234;MN=1011157;Flag=0;CP=&&ExeRtn=1&&09C0
                {
                    SetTextCallback d = new SetTextCallback(SetText);   // 托管调用
                    this.Dispatcher.Invoke(d, new object[] { "请求执行完毕" });
                    if (StartBar.Visibility == Visibility.Visible)
                    {
                        StatueLength = 100;
                    }
                    if (SelfState.ToString().Contains("正在自检"))
                    {
                        lb_status.Dispatcher.BeginInvoke((ThreadStart)delegate { this.lb_status.Text = "自检成功"; });
                        SelfState.Dispatcher.BeginInvoke((ThreadStart)delegate { this.SelfState.Content = "设备自检"; });                    
                    }
                }
                else if (Cmd.Contains("CP=&&ExeRtn=2&&"))
                //##0076QN=20160801085857223;ST=91;CN=9012;PW=1234;MN=1011157;Flag=0;CP=&&ExeRtn=1&&09C0
                {
                    SetTextCallback d = new SetTextCallback(SetText);   // 托管调用
                    this.Dispatcher.Invoke(d, new object[] { "请求执行失败" });
                    if (SelfState.ToString().Contains("正在自检"))
                    {
                        lb_status.Dispatcher.BeginInvoke((ThreadStart)delegate { this.lb_status.Text = "自检失败"; });
                        SelfState.Dispatcher.BeginInvoke((ThreadStart)delegate { this.SelfState.Content = "设备自检"; });

                    }                 
                }
                else
                {

                    if (DataRead["CN"] == "2011")
                    {
                        SetTextCallback d = new SetTextCallback(SetText);   // 托管调用
                        this.Dispatcher.Invoke(d, new object[] { Cmd });
                        SetStringCallback d1 = new SetStringCallback(ShowValue);   // 托管调用
                        this.Dispatcher.Invoke(d1, new object[] { });
                        //string ServiceString = "";
                        //ServiceString = "Data;" + CodeRead["CODE" + CurrrentEllipse] + "," + "Cr=" + DataRead["24-Content"]
                        //    + "Cu=" + DataRead["29-Content"] + "Zn=" + DataRead["30-Content"] + "As=" + DataRead["33-Content"]
                        //    + "Cd=" + DataRead["48-Content"] + "Hg=" + DataRead["80-Content"] + "Pb=" + DataRead["82-Content"];
                        //ShowValue();//将数据显示到屏幕
                        //发送数据至服务器端
                        if (Stop_state == false)
                        {
                            Models.HMDetecResult p = new Models.HMDetecResult
                            {
                                BoxId = _Boxid,
                                // QRCode = CodeRead["CODE" + CurrrentEllipse].ToString(),
                                QRCode = CurrrentEllipse,
                                As = Convert.ToDouble(DataRead["33-Content"]),
                                Cd = Convert.ToDouble(DataRead["48-Content"]),
                                Cr = Convert.ToDouble(DataRead["24-Content"]),
                                Cu = Convert.ToDouble(DataRead["29-Content"]),
                                Hg = Convert.ToDouble(DataRead["80-Content"]),
                                Pb = Convert.ToDouble(DataRead["82-Content"]),
                                Zn = Convert.ToDouble(DataRead["30-Content"])
                            };

                            System.Threading.Tasks.Task.Factory.StartNew(() =>
                            {
                                var result = Operate.UploadResult(p);
                                lb_status.Dispatcher.BeginInvoke((ThreadStart)delegate { this.lb_status.Text = $"发送{p.QRCode}化验结果:{(result.Success ? "成功" : result.Error)}"; });
                            //this.Dispatcher.Invoke(new Action(() => tbx.AppendText($"发送{p.QRCode}化验结果:{(result.Success ? "成功" : result.Error)}")));
                        });
                        }
                        Dci.ReceiveFlag(DataRead["QN"], DataRead["MN"]);
                        Thread.Sleep(100);
                        //soss.SendMeasureValue(ServiceString);//发送数据
                        Measure_state = false;



                    }
                    else
                    {
                        using (FileStream stream = new FileStream(filePath, FileMode.Append))
                        using (StreamWriter writer = new StreamWriter(stream))
                        {
                            writer.WriteLine("接收指令异常:" + Cmd + DateTime.Now.ToString("yyyyMMddhhmmss"));
                            writer.Flush();
                            writer.Close();
                            stream.Close();
                        }
                        MessageBox.Show("接收指令异常：" + Cmd);
                        Measure_state = false;
                    }

                }
            }
            catch (Exception ee)
            {
                using (FileStream stream = new FileStream(filePath, FileMode.Append))
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine("CmdCheck故障:" + Cmd + DateTime.Now.ToString("yyyyMMddhhmmss"));
                    writer.Flush();
                    writer.Close();
                    stream.Close();
                }
                MessageBox.Show("CmdCheck故障:" + Cmd+ee.Message);
            }

        }

        /// <summary>
        /// 关闭主窗口时执行的工作
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        private void Win_closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

            Environment.Exit(0);//强制结束所有线程

        }





        /// <summary>
        /// 按钮弹起效果及相应事件
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        private void StartClick(object sender, MouseButtonEventArgs e)
        {
            IMGSTART.Height = IMGSTART.Height * 1.25;
            IMGSTART.Width = IMGSTART.Width * 1.25;
            IMGSTART.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            try
            {
                if (Dci.bluetoothisConnected)//Dci.bluetoothisConnected
                {
                    if (true)
                    {
                        Thread Measure = new Thread(Measure_all);
                        if (Measure.IsAlive == false)
                        {
                            Stop_state = false;
                            Measure.Start();
                        }
                        else//测量线程已存在
                        {
                            Stop_state = false;
                            Pause_state = false;//取消暂停
                        }
                    }
                    //else if (lb_status.Text.ToString() == "正在暂停……")
                    //{
                    //    Pause_state = false;//取消暂停
                    //    Measure_state= true;
                    //    lb_status.Foreground = System.Windows.Media.Brushes.Blue;
                    //    lb_status.Text = "正在测量……";
                    //    Labelstart.Dispatcher.BeginInvoke((ThreadStart)delegate { this.Labelstart.Content = "测量下一盘"; });
                    //}
                    //else
                    //{
                    //    MessageBox.Show("请扫描样品盘上的条形码");
                    //}
                }
                else
                {
                    MessageBox.Show("设备未连接，出错位置：点击开始测量");
                    using (FileStream stream = new FileStream(filePath, FileMode.Append))
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        writer.WriteLine("设备未连接，出错位置：点击开始测量:" + DateTime.Now.ToString("yyyyMMddhhmmss"));
                        writer.Flush();
                        writer.Close();
                        stream.Close();
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show("开始按键报错："+ee.ToString());
            }
        }
        private void StopClick(object sender, MouseButtonEventArgs e)
        {
            IMGPAUSE.Height = IMGPAUSE.Height * 1.25;
            IMGPAUSE.Width = IMGPAUSE.Width * 1.25;
            IMGPAUSE.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            if (Dci.bluetoothisConnected)
            {
                Dci.StopClick();
                tbx.Text = "停止测量";
                lb_status.Foreground = System.Windows.Media.Brushes.Red;
                lb_status.Text = "正在暂停……";
                Labelstart.Dispatcher.BeginInvoke((ThreadStart)delegate { this.Labelstart.Content = "继续测量"; });
                Pause_state = true;
                Measure_state = false;

            }
            else
            {
                MessageBox.Show("DEVICE DISCONNECTED");
                using (FileStream stream = new FileStream(filePath, FileMode.Append))
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine("设备未连接，出错位置：点击暂停测量:" + DateTime.Now.ToString("yyyyMMddhhmmss"));
                    writer.Flush();
                    writer.Close();
                    stream.Close();
                }
            }

        }

        private void StopAllClick(object sender, MouseButtonEventArgs e)
        {
            IMGSTOP.Height = IMGSTOP.Height * 1.25;
            IMGSTOP.Width = IMGSTOP.Width * 1.25;
            IMGSTOP.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            if (Dci.bluetoothisConnected)
            {
                tbx.Text = "停止测量";
                Dci.StopClick();
                //motor.Reset();
                Stop_state = true;
                CurrrentEllipse = "A0";
                Measure_state = false;
                lb_status.Foreground = System.Windows.Media.Brushes.Red;
                lb_status.Text = "停止测量";
                Labelstart.Dispatcher.BeginInvoke((ThreadStart)delegate { this.Labelstart.Content = "开始测量"; });
            }
            else
            {
                MessageBox.Show("DEVICE DISCONNECTED");
                using (FileStream stream = new FileStream(filePath, FileMode.Append))
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine("设备未连接，出错位置：点击停止测量:" + DateTime.Now.ToString("yyyyMMddhhmmss"));
                    writer.Flush();
                    writer.Close();
                    stream.Close();
                }
            }


        }
        private void SelfCheckClick(object sender, MouseButtonEventArgs e)
        {
            IMGSC.Height = IMGSC.Height * 1.25;
            IMGSC.Width = IMGSC.Width * 1.25;
            IMGSC.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            MessageBox.Show("确保校验块已经正确装入设备");
            SelfState.Content = "正在自检";
            lb_status.Text = "正在自检......";
            if (Dci.bluetoothisConnected)
            {
                if (CurrrentEllipse == "A0")
                {
                    tbx.Text = "设备自检";
                    Thread thread = new Thread(new ThreadStart(() =>
                    {
                        //motor.StartLocation();
                        Thread.Sleep(100);
                        //while (!motor.SerialRece().Contains("StartLocation"))
                        //{
                        //    Thread.Sleep(100);
                        //}
                        //motor.Start();
                        //Thread.Sleep(100);
                        //while (!motor.SerialRece().Contains("Start"))
                        //{
                        //    Thread.Sleep(100);
                        //}
                        Dci.SelfCheckClick();
                        //while ((!lb_status.ToString().Contains( "自检成功"))&&(!lb_status.ToString().Contains("自检失败")));
                        //motor.Reset();
                        //Thread.Sleep(100);
                        //while (!motor.SerialRece().Contains("Reset"))
                        //{
                        //    Thread.Sleep(100);
                        //}
                    }));
                    thread.Start();
                }
                else
                {
                    MessageBox.Show("设备测量过程中禁止自检");
                    using (FileStream stream = new FileStream(filePath, FileMode.Append))
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        writer.WriteLine("设备测量过程中禁止自检:" + DateTime.Now.ToString("yyyyMMddhhmmss"));
                        writer.Flush();
                        writer.Close();
                        stream.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("DEVICE DISCONNECTED");
            }
        }
        private void ShutDown(object sender, MouseButtonEventArgs e)
        {
            IMGST.Height = IMGST.Height * 1.25;
            IMGST.Width = IMGST.Width * 1.25;
            IMGST.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            if (Dci.bluetoothisConnected)
            {
                tbx.Text = "设备关机";
                //motor.OFF();
                Dci.ShutDown();
                //App.Current.MainWindow.Close();
            }
            else
            {
                tbx.Text = "设备开机";
                IMGST_NAME.Content = "关闭探头";
                Thread Serial_Receive = new Thread(Serial_Receive_Function);
                Serial_Receive.Start();
                IMGST.IsEnabled = false;
            }
        }
        private void Serial_Receive_Function()
        {
            Thread thread = new Thread(new ThreadStart(() =>
            {
                for (StatueLength = 0; StatueLength <= 100; StatueLength++)
                {
                    StartBar.Dispatcher.BeginInvoke((ThreadStart)delegate { this.StartBar.Value = StatueLength; });
                    StartProcessPercent.Dispatcher.BeginInvoke((ThreadStart)delegate { this.StartProcessPercent.Content = StatueLength + "%"; });
                    Thread.Sleep(1000);
                }
                IMGST.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGST.IsEnabled = true; });
                IMGSTART.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGSTART.IsEnabled = true; });
                IMGPAUSE.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGPAUSE.IsEnabled = true; });
                IMGSC.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGSC.IsEnabled = true; });
                IMGSTOP.Dispatcher.BeginInvoke((ThreadStart)delegate { this.IMGSTOP.IsEnabled = true; });
                BoxIn.Dispatcher.BeginInvoke((ThreadStart)delegate { this.BoxIn.IsEnabled = true; });
                BoxOut.Dispatcher.BeginInvoke((ThreadStart)delegate { this.BoxOut.IsEnabled = true; });
                Thread.Sleep(1000);
                StartBar.Dispatcher.BeginInvoke((ThreadStart)delegate { this.StartBar.Visibility = Visibility.Hidden; });
                StartProcessPercent.Dispatcher.BeginInvoke((ThreadStart)delegate { this.StartProcessPercent.Visibility = Visibility.Hidden; });
                lb_status.Dispatcher.BeginInvoke((ThreadStart)delegate { this.lb_status.Foreground = System.Windows.Media.Brushes.Blue; });
                lb_status.Dispatcher.BeginInvoke((ThreadStart)delegate { this.lb_status.Text = "初始化完毕，可以开始扫描样品盘编号……"; });


            }));
            thread.Start();
            //motor.ON();
            //while (!motor.SerialRece().Contains("ON"))
            //{
            //    Thread.Sleep(100);
            //}
            //motor.Reset();
            //while (!motor.SerialRece().Contains("Reset"))
            //{
            //    Thread.Sleep(100);
            //}
            //motor.w_reset();
            //while (!motor.SerialRece().Contains("w_reset"))
            //{
            //    Thread.Sleep(100);
            //}
        }





        /// <summary>
        /// 按钮按下效果及相应事件
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        private void StartClickD(object sender, MouseButtonEventArgs e)
        {
            IMGSTART.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
            IMGSTART.Height = IMGSTART.Height * 0.8;
            IMGSTART.Width = IMGSTART.Width * 0.8;
        }
        private void StopClickD(object sender, MouseButtonEventArgs e)
        {
            IMGPAUSE.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
            IMGPAUSE.Height = IMGPAUSE.Height * 0.8;
            IMGPAUSE.Width = IMGPAUSE.Width * 0.8;
        }
        private void StopAllClickD(object sender, MouseButtonEventArgs e)
        {
            IMGSTOP.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
            IMGSTOP.Height = IMGSTOP.Height * 0.8;
            IMGSTOP.Width = IMGSTOP.Width * 0.8;
        }
        private void SelfCheckClickD(object sender, MouseButtonEventArgs e)
        {
            IMGSC.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
            IMGSC.Height = IMGSC.Height * 0.8;
            IMGSC.Width = IMGSC.Width * 0.8;
        }
        private void ShutDownD(object sender, MouseButtonEventArgs e)
        {
            IMGST.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
            IMGST.Height = IMGST.Height * 0.8;
            IMGST.Width = IMGST.Width * 0.8;
        }
        private void MotorWindow_Click(object sender, RoutedEventArgs e)
        {
            MotorSet most = new MotorSet();//实例化页面
            most.ShowDialog();//显示窗口
        }
        private void BoxIn_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            BoxIn.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
            BoxIn.Height = BoxIn.Height * 0.8;
            BoxIn.Width = BoxIn.Width * 0.8;
        }
        private void BoxIn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            BoxIn.Height = BoxIn.Height * 1.25;
            BoxIn.Width = BoxIn.Width * 1.25;
            BoxIn.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            if (Dci.bluetoothisConnected)
            {
                if (CurrrentEllipse == "A0")
                {
                    
                    //motor.BoxIn();
                }
            }
            else
            {
                MessageBox.Show("DEVICE DISCONNECTED");
            }

        }
        private void BoxOut_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            BoxOut.Height = BoxOut.Height * 0.8;
            BoxOut.Width = BoxOut.Width * 0.8;
            BoxOut.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)0);
        }
        private void BoxOut_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            BoxOut.Height = BoxOut.Height * 1.25;
            BoxOut.Width = BoxOut.Width * 1.25;
            BoxOut.Effect.SetValue(DropShadowEffect.ShadowDepthProperty, (Double)5);
            if (Dci.bluetoothisConnected)
            {
                if (CurrrentEllipse =="A0")
                {
                    //motor.BoxOut();
                }
            }
            else
            {
                MessageBox.Show("DEVICE DISCONNECTED");
            }
        }

        private void Settt(object sender, RoutedEventArgs e)
        {
            TtRt most = new TtRt();//实例化页面
            most.ShowDialog();//显示窗口
        }

        private void Settort(object sender, RoutedEventArgs e)
        {
            TestTime most = new TestTime();//实例化页面
            most.ShowDialog();//显示窗口
        }

       
    }
}
