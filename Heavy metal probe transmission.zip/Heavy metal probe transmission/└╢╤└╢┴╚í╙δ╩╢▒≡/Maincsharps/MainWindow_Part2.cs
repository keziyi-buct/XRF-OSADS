﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Input;

namespace 蓝牙读取与识别
{
    public partial class MainWindow
    {
        //TODO:需要做 扫描排斥处理，当扫描完后 开始检测的时候 ，捕获的扫描枪输入 要丢弃
        //可用的 boxid ： SS0001

        private DateTime curInputTime = DateTime.Now;
        private string curInputStr = "";
        private System.Threading.Tasks.Task scanTimer = null;
        private bool isCanScanText = true;

        private string _Boxid = null;
        /// <summary>
        /// 捕获扫描器的输入
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        //private void MainWindow1_PreviewTextInput(object sender, TextCompositionEventArgs e)
        //{

        //    //System.Diagnostics.Debug.WriteLine($"{DateTime.Now.ToString("HH:mm:ss fff")}获取输入{e.Text}");
        //    if (scanTimer == null || scanTimer.IsCompleted)
        //    {
        //        scanTimer = new System.Threading.Tasks.Task(() =>
        //        {
        //            System.Threading.Thread.Sleep(500);
        //            if (curInputStr.Length > 5)//数字为多少 后面根据编码长度来
        //            {
        //                if (isCanScanText)//允许扫描了才替换 才去触发一些事件
        //                {
        //                    this.Dispatcher.Invoke(new Action(() =>
        //                    {
        //                        var boxid = curInputStr.Trim('\r');
        //                        scanText.Content = curInputStr.Trim('\r');
        //                        scanDate.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");

        //                        //已经准备完毕
        //                        var result = Operate.IMReady(boxid);
        //                        if (result.Success)
        //                        {
        //                            _Boxid = boxid;
        //                            lb_status.Foreground = System.Windows.Media.Brushes.Green;
        //                            lb_status.Text = "成功，可以测量";
        //                        }
        //                        else
        //                        {
        //                            lb_status.Foreground = System.Windows.Media.Brushes.Red;
        //                            lb_status.Text = result.Error;
        //                        }
        //                        /*//开始发送数据
        //                        //CmdCheck(BlueToothDataString);                                
        //                        Models.HMDetecResult p = new Models.HMDetecResult
        //                        {
        //                            BoxId = boxid,
        //                            QRCode = "A1",
        //                            As = 1,
        //                            Cd = 2,
        //                            Cr = 3,
        //                            Cu = 4,
        //                            Hg = 5,
        //                            Pb = 0.1,
        //                            Zn = 0.2
        //                        };
        //                        var ss = Operate.UploadResult(p);*/
        //                    }));
        //                    curInputStr = "";
        //                }
        //            }
        //        });
        //        scanTimer.Start();
        //    }
        //    if ((DateTime.Now - curInputTime).TotalMilliseconds < 100)
        //    {
        //        curInputStr += e.Text;
        //        curInputTime = DateTime.Now;
        //    }
        //    else
        //    {
        //        curInputStr = e.Text;
        //        curInputTime = DateTime.Now;
        //    }
        //}

        //是程序显示到最前面API
        [System.Runtime.InteropServices.DllImport("user32", CharSet = System.Runtime.InteropServices.CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetFocus(); //获得本窗体的句柄

        [System.Runtime.InteropServices.DllImport("user32", EntryPoint = "SetForegroundWindow")]

        public static extern bool SetFocus(IntPtr hWnd);

        public IntPtr handle;
        Timer timer = null;
        private void SetWindowToFront()
        {
            //this.MainWindow1.PreviewTextInput += MainWindow1_PreviewTextInput;

            this.MainWindow1.Loaded += (o, a) =>
            {
                handle = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                timer = new Timer(d =>
                {
                    //// 加载一个定时器控件,验证当前WINDOWS句柄是否和本窗体的句柄一样,如果不一样,则激活本窗体
                    //if (handle != GetFocus())
                    //{
                    //    //SetFocus(handle);
                    //    this.Dispatcher.Invoke(new Action(() =>
                    //    {
                    //        this.Activate();
                    //    }));
                    //}

                }, null, 0, 1000);
            };
        }
    }
}
