﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Windows;

namespace 蓝牙读取与识别
{
    interface IMotor
    {
        void SerialInit(string ComNumber, string BaudRate);//初始化串口
        void SerialClose(string ComNumber, string BaudRate);
        void SerialSend(byte[] buff);//串口发送
        string SerialRece();//串口接收
        void NextItem();//下一个
        void PreviousItem();//上一个
        void BoxIn();//盒子进入
        void BoxOut();//盒子退出
        void StartLocation();
        void Start();
        void SelfCheck();
        void Reset();
        void ON();
        void OFF();
        void w_reset();

    }
    class Serial_IO : IMotor
    {
        string Cmd1 = "NextItem";
        string Cmd2 = "PreviousItem";
        string Cmd3 = "BoxIn";
        string Cmd4 = "BoxOut";
        string Cmd5 = "StartLocation";
        string Cmd6 = "Start";
        string Cmd7 = "SelfCheck";
        string Cmd8 = "Reset";
        string Cmd9 = "ON";
        string Cmd10 = "OFF";
        string Cmd11 = "w_reset";
        byte[] buffer = new byte[1024];
        bool dataReady = false;
        string str = "";
        SerialPort MotorMcu = new SerialPort();
        
        public void SerialInit(string ComNumber,string BaudRate)
        {
            try
            {
                MotorMcu.PortName = ComNumber;
                MotorMcu.BaudRate = Convert.ToInt32(BaudRate);
                MotorMcu.ReadTimeout = 30 * 1000;//三十秒钟的超时时间
                MotorMcu.WriteTimeout = 3 * 1000;//三秒钟的超时时间
                MotorMcu.ReceivedBytesThreshold = 1;
                MotorMcu.DataReceived += new SerialDataReceivedEventHandler(SerialRece_Iner);
                MotorMcu.Open();

            }
            catch (Exception)
            {
                MessageBox.Show("串口连接失败，请重新连接");
            }
        }
        public void SerialClose(string ComNumber, string BaudRate)
        {
            if (MotorMcu.IsOpen)
            {
                MotorMcu.Close();
            }
        }

        public void SerialSend(byte [] buff)
        {
            if (MotorMcu.IsOpen)
            {
                MotorMcu.Write(buff, 0, buff.Length);
            }
            else
            {
                MessageBox.Show("串口未打开");
            }
        }

        public void SerialRece_Iner(Object sender, SerialDataReceivedEventArgs e)
        {
            int len = MotorMcu.BytesToRead;
            Byte[] buffer = new Byte[len];
            MotorMcu.Read(buffer,0,len);
            str = Encoding.ASCII.GetString(buffer);
            dataReady = true;
            
        }
        public string SerialRece()
        {
            if (dataReady)
            {
                dataReady = false;
                return str;
            }
            else
                return "";
        }



        public void NextItem()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd1);
            SerialSend(buffer);
        }
        public void PreviousItem()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd2);
            SerialSend(buffer);
        }
        public void BoxIn()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd3);
            SerialSend(buffer);
        }
        public void BoxOut()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd4);
            SerialSend(buffer);
        }
        public void StartLocation()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd5);
            SerialSend(buffer);
        }
        public void Start()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd6);
            SerialSend(buffer);
        }
        public void SelfCheck()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd7);
            SerialSend(buffer);
        }
        public void Reset()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd8);
            SerialSend(buffer);
        }
        public void w_reset()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd11);
            SerialSend(buffer);
        }
        public void ON()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd9);
            SerialSend(buffer);
        }
        public void OFF()
        {
            buffer = Encoding.ASCII.GetBytes(Cmd10);
            SerialSend(buffer);
        }
    }
}


