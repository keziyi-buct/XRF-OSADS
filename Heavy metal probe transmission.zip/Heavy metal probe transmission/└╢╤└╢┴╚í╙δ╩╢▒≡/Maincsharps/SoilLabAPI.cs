﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 蓝牙读取与识别
{
    public class SoilLabAPI
    {
        private const string get_Start_Url = "";
        public void GetPlateStatus(string palteId)
        {
            System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
            client.GetAsync($"{get_Start_Url}?code={palteId}");
        }
    }
}
