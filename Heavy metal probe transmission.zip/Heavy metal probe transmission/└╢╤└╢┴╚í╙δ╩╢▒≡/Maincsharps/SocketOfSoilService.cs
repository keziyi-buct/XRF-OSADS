﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Windows;
using System.Threading;
using System.Windows.Threading;
using System.Configuration;




namespace 蓝牙读取与识别
{
   public class SocketOfSoilService
    {
        
        public static bool socketconnect = false;
        static TcpClient TcpHm = new TcpClient();
        public static ManualResetEvent connectDone =  new ManualResetEvent(false);
        public delegate void SetText_Soss(string text);
        string ConnectSuccessed = "IOTHM0001\r";
       
        /// <summary>
        /// 总调用函数
        /// </summary>
        public  void SocketOfService()
        {

            TcpC();
            Timer_my1();
        }
        
        /// <summary>
        /// 异步TCP连接发起函数
        /// </summary>
        private void TcpC()
        {
            string str1 = ConfigurationManager.AppSettings["ip"];
            if (str1 == "")
            {
                IPAddress[] ips;
                ips = Dns.GetHostAddresses (ConfigurationManager.AppSettings["address"]);
                str1 = ips[0].ToString();
            }
            string str2 = ConfigurationManager.AppSettings["port"];
            TcpHm.BeginConnect(IPAddress.Parse(str1), Convert.ToInt32(str2), new AsyncCallback(TcpCallback), TcpHm);
            
        }

        /// <summary>
        /// 定时初始化函数
        /// </summary>
        private void Timer_my1()
        {
            Timer timer = new Timer(new TimerCallback(TimerCall));
            timer.Change(5000, 5000);
        }

        /// <summary>
        /// 回调函数，在定时函数中反复调用，内容是发送心跳包
        /// </summary>
        /// <param Name="sender"></param>
        /// <param Name="e"></param>
        private void TimerCall(object state)
        {
            byte[] ml = { 0x00};
            Send(ml);
        }

        /// <summary>
        /// TCP回调函数，用于建立异步连接
        /// </summary>
        /// <param Name="ar"></param>
        private void TcpCallback(IAsyncResult ar)
        {
            connectDone.Set();
            TcpClient t = (TcpClient)ar.AsyncState;
            if (t.Connected)
            {
            t.EndConnect(ar);
            socketconnect = true;
            //MainWindow mw = new MainWindow();
            Send(Encoding.UTF8.GetBytes(ConnectSuccessed));
  

            }

        }

        /// <summary>
        /// 数据接收函数，用于读取数据 
        /// </summary>
        /// <returns></returns>
        public string ReadTcp()
        {
            byte[] buffer = new byte[1024];
            string cmd = "";
            try
            {
                NetworkStream StreamHm = TcpHm.GetStream();
                StreamHm.Read(buffer, 0,1024);
                cmd = Encoding.ASCII.GetString(buffer).Trim('\0');
                if (CrcModebus(Encoding.ASCII.GetBytes(cmd.Substring(0, cmd.Length - 6))) == cmd.Substring(cmd.Length - 6, 4))
                {
                    cmd = cmd.Substring(5, cmd.Length - 11);
                }
                else
                {
                    MessageBox.Show("Crc校验错误");
                }

            }
            catch (Exception)
            {

            }
            return cmd;
         
        }

        /// <summary>
        /// 发送函数，使用tcp流写入，将数据发送到服务器
        /// </summary>
        /// <param Name="buffer"></param>
        public  void Send(byte[] buffer)
        {
           
            
            try
            {
                NetworkStream StreamHm = TcpHm.GetStream();
                StreamHm.Write(buffer, 0, buffer.Length);
            }
                catch (Exception)
            {
                socketconnect = false;
                TcpHm=null;
                TcpHm = new TcpClient();
                TcpC();
            }
        
        }

        /// <summary>
        /// CRC——MODEBUS校验函数
        /// </summary>
        /// <param Name="a"></param>
        /// <param Name="len"></param>
        /// <returns></returns>
        public string  CrcModebus(byte []a)
        {
            int CrcR = 0xffff;
            string CrcRStr = "";
            for (int j = 0; j < a.Length; j++)
            {
                CrcR = (CrcR ^ a[j]);
                for (int i = 0; i < 8; i++)
                {
                    if ((CrcR & 0x0001) > 0)
                    {
                        CrcR = (CrcR >> 1);
                        CrcR = (CrcR ^ 0xa001);
                    }
                    else
                    {
                        CrcR = (CrcR >> 1);
                    }
                }
            }
            CrcRStr = Convert.ToString(CrcR, 16);//将无符号整数校验值转换为字符串
            CrcRStr = CrcRStr.ToString().PadLeft(4, '0');//格式化字符串校验值为四位字符型十六进制表示 例如：1E00
            CrcRStr = CrcRStr.ToUpper();
            return CrcRStr;

        }


        /// <summary>
        /// 发送数组组合函数
        /// </summary>
        /// <param Name="Cmd"></param>
        /// <param Name="Crc"></param>
        /// <returns></returns>
        public byte[] SendDataCombine(string Cmd )
        {
            string CombineData = "";
            string Crc = "";
            byte[] CombineBtye;
            CombineData = "##" + Cmd.Length.ToString().PadLeft(3, '0') + Cmd;
            Crc = CrcModebus(Encoding.ASCII.GetBytes(CombineData));
            CombineData = CombineData + Crc + "\r\n";
            CombineBtye = Encoding.ASCII.GetBytes(CombineData);
            return CombineBtye;
        }

        /// <summary>
        /// 指令应答函数
        /// </summary>
        public void ReCmd()
        {
            string cmd = "Rece;0;IOTHM0001;";
            Send(SendDataCombine(cmd));
        }

        /// <summary>
        /// 执行应答函数
        /// </summary>
        public void ReExc()
        {
            string cmd = "Excu;0;IOTHM0001;";
            Send(SendDataCombine(cmd));
        }
        /// <summary>
        /// 执行错误函数
        /// </summary>
        public void ReExcE()
        {
            string cmd = "Excu;1;IOTHM0001;";
            Send(SendDataCombine(cmd));
        }

        /// <summary>
        /// 发送测量值函数
        /// </summary>
        public void SendMeasureValue(string cmd)
        {
            Send(SendDataCombine(cmd));
        }

    }
}
