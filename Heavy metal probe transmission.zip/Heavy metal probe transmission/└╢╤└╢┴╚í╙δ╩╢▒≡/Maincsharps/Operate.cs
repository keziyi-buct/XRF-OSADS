﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 蓝牙读取与识别
{
    public static class Operate
    {

        const string baseurl = " http://175.6.6.113:8100/";
        public static RespResult IMReady(string Boxid)
        {
            var _baseurl = System.Configuration.ConfigurationManager.AppSettings["api_url"] ?? baseurl;
            var weburl = _baseurl + "Soil/IsBoxReady?boxid=" + Boxid;
            string result = WebUtil.GetFromWebApi(null, weburl);
            return Newtonsoft.Json.JsonConvert.DeserializeObject<RespResult>(result);
        }
        public static RespResult UploadResult(Models.HMDetecResult DetecResult)
        {
            var _baseurl = System.Configuration.ConfigurationManager.AppSettings["api_url"] ?? baseurl;
            var weburl = _baseurl + "Soil/PushResult";

            string param = JsonConvert.SerializeObject(DetecResult);

            try
            {
                RespResult obj = null;
                for (int i = 0; i < 3; i++)//重试3次
                {
                    string result = WebUtil.PostFromWebApi(weburl, param);
                    obj = Newtonsoft.Json.JsonConvert.DeserializeObject<RespResult>(result);
                    if (obj.Success)
                        return obj;
                    else
                        System.Threading.Thread.Sleep(1000 * (i + 1));
                }
                return obj;
            }
            catch (Exception ex)
            {
                return new RespResult() { Error = ex.Message };
            }

        }
    }

    public class RespResult
    {
        public int Code { get; set; }
        public string Error { get; set; }
        public object Result { get; set; }
        public bool Success { get; set; }
    }
}
