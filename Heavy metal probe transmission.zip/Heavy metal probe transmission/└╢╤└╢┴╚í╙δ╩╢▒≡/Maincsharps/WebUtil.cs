﻿using System.Collections.Generic;
using System.Web;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System;

namespace 蓝牙读取与识别
{
    public static class WebUtil
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param Name="paramStr"></param>
        /// <param Name="webUri"></param>
        /// <returns></returns>
        public static string GetFromWebApi(string paramStr, string webUri)
        {
            var url = webUri + paramStr;
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var result = client.GetAsync(url).Result;
            return result.Content.ReadAsStringAsync().Result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param Name="url"></param>
        /// <param Name="json"></param>
        /// <returns></returns>
        public static string PostFromWebApi(string url, string json)
        {
            string exmsg = null;
            HttpClient client = new HttpClient();
            for (int i = 0; i < 3; i++)//重试3次
            {
                try
                {
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    var result = client.PostAsync(url, content).Result;
                    return result.Content.ReadAsStringAsync().Result;
                }
                catch (Exception ex)
                {
                    // MessageBox.Show(ex.ToString());
                    exmsg = ex.Message;
                    System.Threading.Thread.Sleep(1000 * (i + 1));
                }
            }
            return exmsg;
        }
    }
}
